export class User {

    id!:number;
    name!:string;
    email!:string;
    mobile!:number;
    password!:string;
    address!:string;

    // constructor(){

    //     this.id=0;
    //     this.name='';
    //     this.email='';
    //     this.mobile=0;
    //     this.password='';
    //     this.address='';

    // }


}
