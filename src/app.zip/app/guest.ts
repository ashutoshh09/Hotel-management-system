export class Guest {

    id!:number;
    name!:string;
    check_in!:string;
    check_out!:string;
    room!:number;
    nosguest!:number;
    // constructor(){
    //     this.id=0;
    //     this.name='';
    //     this.check_in='';
    //     this.check_out='';
    //     this.room=0;
    //     this.nosguest=0;
    // }
}
