export class Service {
    id!:number;
    servicename!:string;
    servicedesc!:string;
    contact!:number;
}
